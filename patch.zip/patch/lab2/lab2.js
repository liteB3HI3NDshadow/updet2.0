var express=require('express');
var bodyParser=require('body-parser');
var urlencodedParser=bodyParser.urlencoded({extended:false});
var app=express();
var expressValidator=require('express-validator');
app.use(expressValidator());
app.get('/',function(req,res)
{
console.log("Got request for homepage");
res.send("<h1>welcome</h1>");
})
app.get('/index2.html',function(req,res)
{
	res.sendFile(__dirname+"/"+"index2.html");
})
app.post('/process_post',urlencodedParser,function(req,res)
{
	req.checkBody('name1').isAlpha();
	req.checkBody('marks1').isInt().notEmpty();
	var errors=req.validationErrors();
	if(errors)
	{
		res.send(errors);
		return;
	}
	else
	{
		console.log("No errors");
  res.send("Data entered </br> USN:" +req.body.usn1+ "<br/>Name:" +req.body.name1 + "<br/> Branch:"+req.body.branch1 +" <br/>Marks:"+req.body.marks1);
}
})
app.listen(9191);
console.log('hi')
