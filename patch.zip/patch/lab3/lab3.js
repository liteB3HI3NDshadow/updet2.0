var express=require('express')
var app=express()
var bodyParse=require('body-parser') 
app.use(bodyParse.urlencoded({extended:false}))
app.get('/',function(req,res){
 res.sendFile(__dirname+"/"+"lab3.html");
});
app.get('/about',function(req,res){
    res.send("hello")
})
app.post('/app',function(req,res){
    var data = 'USERNAME:'+ '<b>' + req.body.user1 + '</b>' + ' <br>BRANCH:' + '<u>'+req.body.branch1 +'</u>'+ '<br>SEMESTER:' + req.body.semester1
    res.send(data+"<br>successfully delivered")
})
app.listen(4242,function(req,res){
    console.log('server running at 4242')
})
