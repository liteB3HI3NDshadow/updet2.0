const bodyparser = require("body-parser");
const express = require("express");
const app = express();
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
app.get("/", (req, res) => {
  res.send("We are Connected");
});
app.get("/ten.html", function (req, res) {
  res.sendFile(__dirname + "/" + "ten.html");
});
app.post("/save", (req, res) => {
	console.log("Student Details FirstName:" +req.body.fname+" LastName:" +req.body.lname+"File Name:"+req.body.fil);
		
		res.send("Student Details:</br>First Name:" +req.body.fname+"<br/>Last Name:" +req.body.lname+"<br/> File Name"+req.body.fil);	
  console.log(req.body.fil);
  res.send(req.body.fil);
});
app.listen(3000);
