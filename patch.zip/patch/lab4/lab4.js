var express=require('express')
var app=express()
var bodyParser=require('body-parser')
var urlencodedParser=bodyParser.urlencoded({extended:false})
var expressValidator=require('express-validator');
app.use(expressValidator());
var ejs=require('ejs')
var MongoClient=require('mongodb').MongoClient
MongoClient.connect("mongodb://localhost/empdb",function(err,db)
{
        if(!err)
        {
                console.log("We are connected");
                app.get('/',function(req,res)
                {
                        res.send("Welcome");
                })
                app.get('/index4.html',function(req,res)
                {
                        res.sendFile(__dirname+"/"+"index4.html")
                })
                app.post('/process_post',urlencodedParser,function(req,res)
                {
        req.checkBody('name','Employee Name field can not be empty').notEmpty();
        req.checkBody('empid','Employee ID field can not be empty').notEmpty();
        req.checkBody('name','Name should contain only characters').isAlpha();
        req.checkBody('empid','Invalid Employee ID').isInt();
        var errors=req.validationErrors();
        if(errors)
        {
                res.send(errors);
                return;
        }
        else
        {
                        var EMPID=req.body.empid
                        var NAME=req.body.name
                        var DEPARTMENT=req.body.dept
                        var DESIGNATION=req.body.desig
                        var MOBILE=req.body.mob
                        var EMAIL=req.body.email
db.collection('employee').insert({"empid":EMPID,"name":NAME,"dept":DEPARTMENT,"desig":DESIGNATION,"mob":MOBILE,"email":EMAIL},function(err,doc)
{
                                if(err)
                                        return console.log(err)
                                else
                                        res.status(201).json(doc.ops[1])
                        })
                        console.log("Record Inserted!!");
                        res.send('<p>NAME : '+req.body.name+'</p><p>EMPID : '+req.body.empid+'</p><p>DEPARTMENT : '+req.body.dept+'</p><p>DESIGNATION : '+req.body.desig+'</p>')
        }
                })
                app.get('/display',function (req, res) 
        { 
                db.collection('employee').find().toArray(function(err , i)
                {
                        if (err) 
                                return console.log(err)
                        res.render('Emp.ejs',{employee: i})  
                })
        }) 
      app.get('/sort',function(req,res)
                {
                        db.collection('employee').find().sort({empid: 1}).toArray(function(err,i)
                        {
                                if(err)
                                        return console.log(err);
                                res.render('Emp.ejs',{employee:i})
                        })
                })
                app.listen(4100);
                console.log("Server is running");
        }
        else db.close();
})
