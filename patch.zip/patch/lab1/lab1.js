var express = require('express')
var app = express()
const hostname= 'localhost';
const http= require('http');
const port= 4000;
var d=new Date()
var requestTime = function (req, res, next) {
  req.requestTime = d.toLocaleString()
  console.log('current Time: '+req.requestTime)
  next()
}
var Url = function (req,res,next) {
console.log('current url: '+req.url)
next()
}
app.use(Url)
app.use(requestTime)
app.get('/', function (req, res) {
  var responseText = 'HELLO WORLD!<br>'
  responseText += '<small>current url: ' + req.url+ '</small><br>'
  responseText += '<small>Requested at: ' + req.requestTime + '</small>'
  res.send(responseText)
})
const server= http.createServer(app)
server.listen(port,hostname,()=> {
console.log(`server running at http://${hostname}: ${port}`)
});
console.log('server started')
